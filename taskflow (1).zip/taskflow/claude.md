# claude.md — AI Agent Guidance for TaskFlow

This file describes conventions, constraints, and context for AI agents (Claude, Copilot, etc.) working on this codebase.

---

## Project Overview

TaskFlow is a full-stack task management app:
- **Backend:** Python 3.11, Flask 3.0, SQLAlchemy, SQLite
- **Frontend:** React 18, Vite, React Query, CSS Modules
- **AI:** Anthropic Claude (`claude-sonnet-4-20250514`)

---

## Coding Standards

### Python / Flask

- Use the **app factory pattern** (`create_app()`). Never import `app` from the module level in tests.
- All routes must be in **Blueprints** under `app/routes/`.
- Return consistent JSON error shapes: `{"error": "message"}` with appropriate HTTP status codes.
- Use SQLAlchemy ORM — no raw SQL strings.
- Validate required fields in route handlers; return 400 if missing.
- Enums for `status` and `priority` — don't accept arbitrary strings.
- Always call `db.session.commit()` after mutations.

### React / Frontend

- Use **React Query** (`useQuery`, `useMutation`) for all server state. No `useEffect` for data fetching.
- Invalidate queries after mutations: `qc.invalidateQueries({ queryKey: ['tasks'] })`.
- **CSS Modules** only — no inline styles except for dynamic values (colors, percentages).
- Use CSS custom properties from `index.css` for all colors and spacing.
- No hardcoded color values in components.
- Components should be focused: one responsibility per file.

### AI Endpoints

- Always prompt Claude to return **JSON only** — no markdown, no preamble.
- Strip code fences defensively before `JSON.parse`.
- Wrap AI calls in try/catch. Return HTTP 503 if `ANTHROPIC_API_KEY` is missing.
- Don't call AI endpoints on page load — all AI is user-triggered.

---

## File Structure Conventions

```
backend/app/routes/       ← one Blueprint per resource
backend/app/models.py     ← all models in one file (small app)
backend/tests/            ← pytest tests, use in-memory SQLite
frontend/src/pages/       ← one file per page + co-located .module.css
frontend/src/api/index.js ← all API calls centralized here
frontend/src/utils/       ← config constants (priority colors, etc.)
```

---

## What NOT to do

- Don't add authentication — out of scope for this assessment
- Don't use Redux or Zustand — React Query is sufficient
- Don't use `fetch` directly in components — use the `api/index.js` module
- Don't add external CSS frameworks (Tailwind, Bootstrap) — CSS Modules only
- Don't add new Python dependencies without updating `requirements.txt`
- Don't store secrets in code — use `.env` (gitignored)

---

## Testing Conventions

- Backend tests use `pytest` with a fresh in-memory SQLite DB per test
- Test file: `backend/tests/test_api.py`
- Each route should have at least: happy path, validation error, and not-found case
- No mocking of the DB — use real SQLite in tests

---

## Environment Variables

| Variable            | Required | Description                          |
|---------------------|----------|--------------------------------------|
| `ANTHROPIC_API_KEY` | No       | Enables AI features. App works without it. |
| `DATABASE_URL`      | No       | Defaults to `sqlite:///taskflow.db`  |
| `SECRET_KEY`        | Yes (prod)| Flask session secret                 |

---

## Prompting Notes for AI Agents

When generating code for this project:

1. Follow the existing patterns — look at `tasks.py` before writing a new route
2. Check `models.py` before adding fields — keep model changes backwards-compatible
3. When modifying AI prompts in `ai.py`, always test that the response can be `JSON.parse`d
4. CSS: use `var(--accent)`, `var(--text-2)` etc. — never raw hex values
5. React components: check if a similar component already exists before creating one
