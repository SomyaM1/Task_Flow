# Architecture Overview

## High-Level Design

```
┌─────────────────────────────────────────────────────────┐
│                     Browser (React)                       │
│  Dashboard | Tasks | Projects | AI Tools                  │
│  React Query cache ↕ axios ↕ Vite dev proxy               │
└───────────────────────┬─────────────────────────────────┘
                        │ HTTP /api/*
┌───────────────────────▼─────────────────────────────────┐
│              Flask API (Python 3.11)                      │
│  Blueprints: /tasks  /projects  /ai  /health              │
│  Flask-SQLAlchemy ORM                                     │
└───────────┬───────────────────────┬─────────────────────┘
            │ SQLAlchemy            │ anthropic SDK
┌───────────▼────────┐   ┌──────────▼─────────────────────┐
│  SQLite / Postgres  │   │  Anthropic API (Claude Sonnet)  │
│  tasks, projects    │   │  prioritize / suggest / summarize│
└────────────────────┘   └────────────────────────────────┘
```

## Backend Layers

### App Factory (`app/__init__.py`)
Uses the Flask application factory pattern. This allows creating fresh app instances for tests with different configs (e.g. in-memory SQLite).

### Models (`app/models.py`)
Two main models:

**Project**
- id, name, description, color, created_at, updated_at
- Has many Tasks (cascade delete)

**Task**
- id, title, description, status (enum), priority (enum)
- ai_priority_score (float), ai_reasoning (text) — populated by AI
- due_date, project_id, tags (comma-separated), created_at, updated_at, completed_at

Using SQLAlchemy enums for status/priority ensures data integrity at the ORM level.

### Routes (Blueprints)
Each resource has its own Blueprint, registered with a URL prefix:
- `tasks_bp` → `/api/tasks/`
- `projects_bp` → `/api/projects/`
- `ai_bp` → `/api/ai/`
- `health_bp` → `/api/`

### AI Integration (`app/routes/ai.py`)
Three endpoints, each building a structured prompt and calling `claude-sonnet-4-20250514`:

1. `POST /api/ai/prioritize` — Serializes all non-done tasks to JSON, sends to Claude, parses scores, writes back to DB
2. `POST /api/ai/suggest` — Takes a goal string, gets back 5–8 task suggestions as JSON
3. `GET /api/ai/summarize` — Gets a plain-text workload summary

AI is optional: if `ANTHROPIC_API_KEY` is not set, all AI endpoints return HTTP 503 with a clear message. The frontend surfaces this gracefully.

## Frontend Architecture

### State Management
No Redux or Zustand — React Query handles all server state:
- Cache keys are `['tasks', params]`, `['projects']`, `['stats']`
- Mutations always call `invalidateQueries` to keep UI in sync
- `staleTime: 30s` reduces redundant fetches

### Routing
React Router v6 with a persistent sidebar layout. All routes are under the single `App` component which owns the sidebar.

### Styling
CSS Modules for scoped, co-located styles. Global design tokens in `index.css` using CSS custom properties (`--bg`, `--accent`, etc.). No CSS-in-JS runtime cost.

### API Client
Single `axios` instance with `/api` baseURL. Vite proxy forwards to Flask in dev; in production a reverse proxy (nginx) would do the same.
