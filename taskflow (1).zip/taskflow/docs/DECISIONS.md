# Technical Decisions

## 1. SQLite as default database

**Decision:** Use SQLite in development via a `DATABASE_URL` env var that defaults to `sqlite:///taskflow.db`.

**Rationale:** Zero-config setup — no Docker, no Postgres install needed to run the project. The schema uses standard SQL types and SQLAlchemy abstractions, so swapping to PostgreSQL is a one-line env var change. Flask-Migrate is already wired up for production migrations.

**Trade-off:** SQLite has no connection pooling and limited concurrency. Acceptable for a local/demo app; not for multi-user production.

---

## 2. Flask App Factory Pattern

**Decision:** `create_app()` factory function instead of a module-level app object.

**Rationale:** Enables clean testing — `pytest` creates a fresh app with `SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"` per test, ensuring full isolation. Also enables future multi-environment configs (dev/staging/prod) without code changes.

---

## 3. React Query for server state

**Decision:** `@tanstack/react-query` instead of `useEffect` + `useState` or Redux.

**Rationale:** Eliminates ~70% of boilerplate (loading states, error states, cache invalidation). The key-based cache model maps cleanly to REST resources. Mutations auto-invalidate related queries. No global store setup needed.

---

## 4. Storing AI scores in the database

**Decision:** `ai_priority_score` and `ai_reasoning` are persisted columns on the `tasks` table.

**Rationale:** AI calls are expensive and slow. Scores should persist between page loads. Users can re-run prioritization at any time. This also allows sorting by AI score server-side.

**Trade-off:** Scores become stale as tasks change. A future improvement would be a `scored_at` timestamp and auto-re-scoring rules.

---

## 5. JSON-first AI prompts

**Decision:** All three AI endpoints instruct Claude to respond with JSON only and strip markdown fences defensively.

**Rationale:** Reliable parsing. The alternative (free-text parsing) is fragile. Asking for JSON and validating the schema is the most robust approach for structured AI outputs.

---

## 6. Comma-separated tags (not a join table)

**Decision:** `tags` is stored as a comma-separated string, not a normalized `task_tags` junction table.

**Rationale:** Given the scope of this assessment, a junction table would add complexity (tag CRUD endpoints, migrations) without meaningful benefit. The API serializes/deserializes cleanly. Easy to migrate later if tag search or reuse becomes important.

---

## 7. CSS Modules over Tailwind / CSS-in-JS

**Decision:** CSS Modules with CSS custom properties (variables).

**Rationale:** No build tooling dependencies, no purge config, no class-name memorization. Styles are co-located and scoped. CSS variables give a consistent design token system. Tailwind would work but adds a compilation step and obscures intent in JSX.

---

## 8. Vite proxy in development

**Decision:** Vite's `server.proxy` forwards `/api` to Flask at port 5000.

**Rationale:** Eliminates CORS headers in Flask during development while keeping the two servers independent. CORS is still configured in Flask for production builds where a reverse proxy isn't available.

---

## Risks

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Anthropic API rate limits | Medium | AI calls are user-triggered, not automatic |
| AI returns malformed JSON | Low | Defensive JSON parsing with try/catch + code fence stripping |
| SQLite lock contention | Low (dev only) | Switch to Postgres for production |
| Stale AI scores misleading users | Medium | Show score age; add "re-prioritize" CTA |

---

## Extension Approach

**Authentication:** Add `flask-jwt-extended`. Add `user_id` FK to `Task` and `Project`. All queries filter by `current_user`. JWT tokens issued on login.

**PostgreSQL:** Change `DATABASE_URL` env var. Run `flask db upgrade` to apply existing migrations.

**Real-time sync:** Add `flask-socketio`. Emit events on task create/update/delete. Frontend subscribes with `socket.io-client`.

**Background AI re-scoring:** Add Celery + Redis. Schedule periodic re-prioritization job that only updates tasks modified since last run.
