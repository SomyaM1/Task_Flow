# TaskFlow — AI-Powered Task Manager

A full-stack task management application with AI-powered prioritization, built with Python/Flask, React, and SQLite.

## 🚀 Features

- **Task Management** — Create, update, delete, filter, and sort tasks with priorities, statuses, due dates, tags, and projects
- **Project Management** — Group tasks into color-coded projects with progress tracking
- **AI Prioritization** — Claude analyzes all pending tasks and assigns priority scores (0–10) with reasoning
- **AI Workload Summary** — Natural language summary of current workload with recommendations
- **AI Task Generator** — Describe a goal and get a set of suggested tasks, addable with one click
- **Dashboard** — At-a-glance stats: completion rates, overdue count, top AI-ranked tasks

## 🏗 Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Backend   | Python 3.11+, Flask 3.0, SQLAlchemy |
| Database  | SQLite (dev) / PostgreSQL (prod)    |
| Frontend  | React 18, Vite, React Query, React Router |
| AI        | Anthropic Claude (claude-sonnet-4)  |

---

## ⚙️ Setup

### Prerequisites
- Python 3.11+
- Node.js 18+
- Anthropic API key (for AI features)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env — add your ANTHROPIC_API_KEY

# Run
python run.py
# API available at http://localhost:5000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
# App available at http://localhost:3000
```

### Run Tests

```bash
cd backend
pytest tests/ -v
```

---

## 📡 API Reference

### Tasks

| Method | Endpoint             | Description           |
|--------|---------------------|-----------------------|
| GET    | `/api/tasks/`        | List tasks (filterable) |
| POST   | `/api/tasks/`        | Create task           |
| GET    | `/api/tasks/:id`     | Get task              |
| PUT    | `/api/tasks/:id`     | Update task           |
| DELETE | `/api/tasks/:id`     | Delete task           |
| GET    | `/api/tasks/stats`   | Aggregate stats       |

**Query params for GET /tasks/:** `status`, `priority`, `project_id`, `search`, `sort_by`, `order`

### Projects

| Method | Endpoint               | Description     |
|--------|------------------------|-----------------|
| GET    | `/api/projects/`       | List projects   |
| POST   | `/api/projects/`       | Create project  |
| PUT    | `/api/projects/:id`    | Update project  |
| DELETE | `/api/projects/:id`    | Delete project  |

### AI

| Method | Endpoint              | Description                      |
|--------|-----------------------|----------------------------------|
| POST   | `/api/ai/prioritize`  | Score all pending tasks with AI  |
| POST   | `/api/ai/suggest`     | Suggest tasks for a given goal   |
| GET    | `/api/ai/summarize`   | Natural language workload summary |

### Health

| Method | Endpoint       | Description        |
|--------|----------------|--------------------|
| GET    | `/api/health`  | Service status     |

---

## 🗂 Project Structure

```
taskflow/
├── backend/
│   ├── app/
│   │   ├── __init__.py       # App factory, extensions
│   │   ├── models.py         # SQLAlchemy models (Task, Project)
│   │   └── routes/
│   │       ├── tasks.py      # Task CRUD + stats
│   │       ├── projects.py   # Project CRUD
│   │       ├── ai.py         # AI endpoints (Claude)
│   │       └── health.py     # Health check
│   ├── tests/
│   │   └── test_api.py       # Pytest API tests
│   ├── run.py                # Entry point
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── api/index.js      # Axios API client
│   │   ├── pages/            # Dashboard, Tasks, Projects, AiTools
│   │   ├── utils/config.js   # Priority/status config
│   │   ├── App.jsx           # Router + layout
│   │   └── index.css         # Global design system
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── docs/
│   ├── ARCHITECTURE.md
│   └── DECISIONS.md
├── claude.md                 # AI guidance file
└── README.md
```

---

## 🔑 Key Technical Decisions

See `docs/DECISIONS.md` for a detailed breakdown.

**Short version:**
- **SQLite** for zero-config local development, swappable via `DATABASE_URL` env var
- **Flask app factory** pattern for clean testing and extensibility
- **React Query** for server state — no manual loading state or cache management
- **CSS Modules** to keep styles scoped and co-located
- **Vite proxy** so frontend dev server routes `/api/*` to Flask without CORS issues
- **Structured AI prompts** that always request JSON — no markdown parsing surprises
- **Graceful AI degradation** — AI features show clear error messages if the API key isn't set

---

## 🤖 AI Usage

AI features are powered by `claude-sonnet-4-20250514`. Three use cases:

1. **Prioritization** — Sends all non-done tasks as JSON to Claude and gets back scores + reasoning. Scores are stored in the DB so they persist.
2. **Suggestions** — Given a plain-English goal, Claude returns a structured list of tasks ready to be created.
3. **Summary** — Claude reads the task list and writes a 3-4 sentence actionable summary.

All prompts explicitly request JSON-only responses and strip markdown code fences before parsing.

---

## 🚀 Extending TaskFlow

- **Auth** — Add Flask-JWT-Extended; tasks/projects get a `user_id` FK
- **PostgreSQL** — Change `DATABASE_URL`; schema is already migration-ready with Flask-Migrate
- **Real-time** — Add Flask-SocketIO for live task updates across tabs
- **Recurring tasks** — Add a `recurrence_rule` field + Celery beat scheduler
- **AI chat** — Add a conversational interface using Claude multi-turn messages
