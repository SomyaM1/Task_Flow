import pytest
import json
from app import create_app, db


@pytest.fixture
def app():
    app = create_app()
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def test_health(client):
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "ok"


def test_create_task(client):
    res = client.post(
        "/api/tasks/",
        json={"title": "Test task", "priority": "high"},
        content_type="application/json",
    )
    assert res.status_code == 201
    data = res.get_json()
    assert data["title"] == "Test task"
    assert data["priority"] == "high"
    assert data["status"] == "todo"


def test_get_tasks(client):
    client.post("/api/tasks/", json={"title": "Task 1"})
    client.post("/api/tasks/", json={"title": "Task 2"})
    res = client.get("/api/tasks/")
    assert res.status_code == 200
    data = res.get_json()
    assert len(data) == 2


def test_update_task(client):
    res = client.post("/api/tasks/", json={"title": "Original"})
    task_id = res.get_json()["id"]
    res = client.put(f"/api/tasks/{task_id}", json={"title": "Updated", "status": "done"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["title"] == "Updated"
    assert data["status"] == "done"
    assert data["completed_at"] is not None


def test_delete_task(client):
    res = client.post("/api/tasks/", json={"title": "To Delete"})
    task_id = res.get_json()["id"]
    res = client.delete(f"/api/tasks/{task_id}")
    assert res.status_code == 200
    res = client.get(f"/api/tasks/{task_id}")
    assert res.status_code == 404


def test_create_project(client):
    res = client.post(
        "/api/projects/",
        json={"name": "My Project", "color": "#ff0000"},
    )
    assert res.status_code == 201
    data = res.get_json()
    assert data["name"] == "My Project"
    assert data["color"] == "#ff0000"


def test_task_stats(client):
    client.post("/api/tasks/", json={"title": "T1", "status": "done"})
    client.put("/api/tasks/1", json={"status": "done"})
    res = client.get("/api/tasks/stats")
    assert res.status_code == 200
    data = res.get_json()
    assert "total" in data
    assert "completion_rate" in data


def test_task_missing_title(client):
    res = client.post("/api/tasks/", json={"description": "No title"})
    assert res.status_code == 400
