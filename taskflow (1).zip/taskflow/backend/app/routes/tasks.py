from flask import Blueprint, request, jsonify
from app import db
from app.models import Task, Status, Priority
from datetime import datetime

tasks_bp = Blueprint("tasks", __name__)


def parse_priority(val):
    try:
        return Priority(val)
    except (ValueError, KeyError):
        return Priority.MEDIUM


def parse_status(val):
    try:
        return Status(val)
    except (ValueError, KeyError):
        return Status.TODO


@tasks_bp.route("/", methods=["GET"])
def get_tasks():
    status = request.args.get("status")
    priority = request.args.get("priority")
    project_id = request.args.get("project_id")
    search = request.args.get("search")
    sort_by = request.args.get("sort_by", "created_at")
    order = request.args.get("order", "desc")

    query = Task.query

    if status:
        query = query.filter(Task.status == parse_status(status))
    if priority:
        query = query.filter(Task.priority == parse_priority(priority))
    if project_id:
        query = query.filter(Task.project_id == int(project_id))
    if search:
        query = query.filter(
            Task.title.ilike(f"%{search}%") | Task.description.ilike(f"%{search}%")
        )

    if sort_by == "ai_priority_score":
        col = Task.ai_priority_score
    elif sort_by == "due_date":
        col = Task.due_date
    elif sort_by == "priority":
        col = Task.priority
    else:
        col = Task.created_at

    if order == "asc":
        query = query.order_by(col.asc().nullslast())
    else:
        query = query.order_by(col.desc().nullslast())

    tasks = query.all()
    return jsonify([t.to_dict() for t in tasks])


@tasks_bp.route("/", methods=["POST"])
def create_task():
    data = request.get_json()
    if not data or not data.get("title"):
        return jsonify({"error": "Title is required"}), 400

    due_date = None
    if data.get("due_date"):
        try:
            due_date = datetime.fromisoformat(data["due_date"].replace("Z", "+00:00"))
        except ValueError:
            pass

    task = Task(
        title=data["title"],
        description=data.get("description"),
        status=parse_status(data.get("status", "todo")),
        priority=parse_priority(data.get("priority", "medium")),
        due_date=due_date,
        project_id=data.get("project_id"),
        tags=",".join(data.get("tags", [])) if data.get("tags") else None,
    )
    db.session.add(task)
    db.session.commit()
    return jsonify(task.to_dict()), 201


@tasks_bp.route("/<int:task_id>", methods=["GET"])
def get_task(task_id):
    task = Task.query.get_or_404(task_id)
    return jsonify(task.to_dict())


@tasks_bp.route("/<int:task_id>", methods=["PUT"])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    data = request.get_json()

    if "title" in data:
        task.title = data["title"]
    if "description" in data:
        task.description = data["description"]
    if "status" in data:
        new_status = parse_status(data["status"])
        if new_status == Status.DONE and task.status != Status.DONE:
            task.completed_at = datetime.utcnow()
        elif new_status != Status.DONE:
            task.completed_at = None
        task.status = new_status
    if "priority" in data:
        task.priority = parse_priority(data["priority"])
    if "project_id" in data:
        task.project_id = data["project_id"]
    if "tags" in data:
        task.tags = ",".join(data["tags"]) if data["tags"] else None
    if "due_date" in data:
        if data["due_date"]:
            try:
                task.due_date = datetime.fromisoformat(data["due_date"].replace("Z", "+00:00"))
            except ValueError:
                pass
        else:
            task.due_date = None
    if "ai_priority_score" in data:
        task.ai_priority_score = data["ai_priority_score"]
    if "ai_reasoning" in data:
        task.ai_reasoning = data["ai_reasoning"]

    task.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify(task.to_dict())


@tasks_bp.route("/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({"message": "Task deleted"}), 200


@tasks_bp.route("/stats", methods=["GET"])
def get_stats():
    total = Task.query.count()
    done = Task.query.filter_by(status=Status.DONE).count()
    in_progress = Task.query.filter_by(status=Status.IN_PROGRESS).count()
    todo = Task.query.filter_by(status=Status.TODO).count()
    urgent = Task.query.filter_by(priority=Priority.URGENT).count()
    overdue = Task.query.filter(
        Task.due_date < datetime.utcnow(),
        Task.status != Status.DONE
    ).count()

    return jsonify({
        "total": total,
        "done": done,
        "in_progress": in_progress,
        "todo": todo,
        "urgent": urgent,
        "overdue": overdue,
        "completion_rate": round((done / total * 100) if total > 0 else 0, 1),
    })
