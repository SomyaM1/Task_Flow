from flask import Blueprint, request, jsonify
from app import db
from app.models import Task, Status
import os
import json

ai_bp = Blueprint("ai", __name__)


def get_anthropic_client():
    import anthropic
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    return anthropic.Anthropic(api_key=api_key)


@ai_bp.route("/prioritize", methods=["POST"])
def prioritize_tasks():
    """Use Claude to analyze and score all pending tasks by priority."""
    client = get_anthropic_client()
    if not client:
        return jsonify({"error": "AI not configured. Set ANTHROPIC_API_KEY."}), 503

    tasks = Task.query.filter(Task.status != Status.DONE).all()
    if not tasks:
        return jsonify({"message": "No tasks to prioritize", "updated": 0})

    task_list = []
    for t in tasks:
        task_list.append({
            "id": t.id,
            "title": t.title,
            "description": t.description or "",
            "priority": t.priority.value,
            "due_date": t.due_date.isoformat() if t.due_date else None,
            "status": t.status.value,
            "tags": t.tags or "",
        })

    prompt = f"""You are a productivity expert. Analyze the following tasks and assign each a priority score from 0.0 to 10.0, where 10.0 is the most urgent/important.

Consider:
- Due dates (closer = higher score)
- Existing priority level (urgent > high > medium > low)  
- Task descriptions for implied urgency
- Dependencies implied by task names/tags
- Whether it's blocking other work

Tasks to analyze:
{json.dumps(task_list, indent=2)}

Respond ONLY with a JSON array. Each item must have:
- "id": (integer task id)
- "score": (float 0.0-10.0)
- "reasoning": (1-2 sentence explanation)

Example format:
[{{"id": 1, "score": 8.5, "reasoning": "Has a near due date and is marked urgent."}}]

Return ONLY the JSON array, no other text."""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}],
        )

        response_text = message.content[0].text.strip()
        # Strip markdown code fences if present
        if response_text.startswith("```"):
            lines = response_text.split("\n")
            response_text = "\n".join(lines[1:-1])

        scores = json.loads(response_text)

        updated = 0
        for item in scores:
            task = Task.query.get(item["id"])
            if task:
                task.ai_priority_score = item["score"]
                task.ai_reasoning = item.get("reasoning", "")
                updated += 1

        db.session.commit()
        return jsonify({
            "message": f"AI prioritized {updated} tasks",
            "updated": updated,
            "scores": scores,
        })

    except json.JSONDecodeError as e:
        return jsonify({"error": f"Failed to parse AI response: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"AI error: {str(e)}"}), 500


@ai_bp.route("/suggest", methods=["POST"])
def suggest_tasks():
    """Given a project/goal description, suggest a list of tasks."""
    client = get_anthropic_client()
    if not client:
        return jsonify({"error": "AI not configured. Set ANTHROPIC_API_KEY."}), 503

    data = request.get_json()
    goal = data.get("goal", "")
    project_id = data.get("project_id")

    if not goal:
        return jsonify({"error": "Goal description required"}), 400

    prompt = f"""You are a project planning expert. Break down the following goal into actionable tasks.

Goal: {goal}

Generate 5-8 specific, actionable tasks. For each task provide:
- title: clear, concise action (start with verb)
- description: 1-2 sentences of detail
- priority: one of "low", "medium", "high", "urgent"
- suggested_tags: array of 1-3 relevant tags

Respond ONLY with a JSON array of task objects. No other text.

Example:
[{{"title": "Research competitors", "description": "Analyze top 5 competitors' features and pricing.", "priority": "high", "suggested_tags": ["research", "strategy"]}}]"""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}],
        )

        response_text = message.content[0].text.strip()
        if response_text.startswith("```"):
            lines = response_text.split("\n")
            response_text = "\n".join(lines[1:-1])

        suggestions = json.loads(response_text)
        return jsonify({"suggestions": suggestions})

    except json.JSONDecodeError as e:
        return jsonify({"error": f"Failed to parse AI response: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"AI error: {str(e)}"}), 500


@ai_bp.route("/summarize", methods=["GET"])
def summarize_workload():
    """Give a natural language summary of the current workload."""
    client = get_anthropic_client()
    if not client:
        return jsonify({"error": "AI not configured. Set ANTHROPIC_API_KEY."}), 503

    tasks = Task.query.filter(Task.status != Status.DONE).all()
    if not tasks:
        return jsonify({"summary": "You have no pending tasks. Great job! 🎉"})

    task_list = [
        {
            "title": t.title,
            "priority": t.priority.value,
            "status": t.status.value,
            "due_date": t.due_date.isoformat() if t.due_date else None,
            "ai_score": t.ai_priority_score,
        }
        for t in tasks
    ]

    prompt = f"""You are a productivity coach. Analyze this task list and give a brief, encouraging, actionable summary of the current workload in 3-4 sentences. Highlight what needs attention first and any risks.

Tasks: {json.dumps(task_list, indent=2)}

Be concise, helpful, and motivating. Respond with plain text only."""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        summary = message.content[0].text.strip()
        return jsonify({"summary": summary})
    except Exception as e:
        return jsonify({"error": f"AI error: {str(e)}"}), 500
