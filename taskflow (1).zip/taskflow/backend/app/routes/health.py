from flask import Blueprint, jsonify
import os

health_bp = Blueprint("health", __name__)


@health_bp.route("/health", methods=["GET"])
def health():
    ai_configured = bool(os.getenv("ANTHROPIC_API_KEY"))
    return jsonify({
        "status": "ok",
        "service": "TaskFlow API",
        "version": "1.0.0",
        "ai_enabled": ai_configured,
    })
