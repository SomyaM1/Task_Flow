from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_migrate import Migrate
from dotenv import load_dotenv
import os

load_dotenv()

db = SQLAlchemy()
migrate = Migrate()


def create_app(config_name=None):
    app = Flask(__name__)

    # Configuration
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-key-change-in-prod")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
        "DATABASE_URL", "sqlite:///taskflow.db"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app, origins=["http://localhost:3000", "http://localhost:5173"])

    # Blueprints
    from app.routes.tasks import tasks_bp
    from app.routes.projects import projects_bp
    from app.routes.ai import ai_bp
    from app.routes.health import health_bp

    app.register_blueprint(tasks_bp, url_prefix="/api/tasks")
    app.register_blueprint(projects_bp, url_prefix="/api/projects")
    app.register_blueprint(ai_bp, url_prefix="/api/ai")
    app.register_blueprint(health_bp, url_prefix="/api")

    return app
