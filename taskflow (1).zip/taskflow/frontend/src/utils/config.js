export const PRIORITY_CONFIG = {
  low:    { label: 'Low',    color: '#5a5a78' },
  medium: { label: 'Medium', color: '#60a5fa' },
  high:   { label: 'High',   color: '#fbbf24' },
  urgent: { label: 'Urgent', color: '#f87171' },
}

export const STATUS_CONFIG = {
  todo:        { label: 'To Do',       color: '#9898b8' },
  in_progress: { label: 'In Progress', color: '#60a5fa' },
  done:        { label: 'Done',        color: '#34d399' },
  archived:    { label: 'Archived',    color: '#5a5a78' },
}

export const PROJECT_COLORS = [
  '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e',
  '#f97316', '#eab308', '#22c55e', '#14b8a6', '#06b6d4',
]
