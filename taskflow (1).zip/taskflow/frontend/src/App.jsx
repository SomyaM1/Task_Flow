import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getHealth } from './api'
import Dashboard from './pages/Dashboard'
import Tasks from './pages/Tasks'
import Projects from './pages/Projects'
import AiTools from './pages/AiTools'
import styles from './App.module.css'
import { LayoutDashboard, CheckSquare, FolderOpen, Sparkles, Zap } from 'lucide-react'

export default function App() {
  const { data: health } = useQuery({
    queryKey: ['health'],
    queryFn: getHealth,
    retry: false,
  })

  return (
    <BrowserRouter>
      <div className={styles.layout}>
        <aside className={styles.sidebar}>
          <div className={styles.logo}>
            <Zap size={20} className={styles.logoIcon} />
            <span>TaskFlow</span>
          </div>
          <nav className={styles.nav}>
            <NavLink to="/dashboard" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}>
              <LayoutDashboard size={16} /> Dashboard
            </NavLink>
            <NavLink to="/tasks" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}>
              <CheckSquare size={16} /> Tasks
            </NavLink>
            <NavLink to="/projects" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}>
              <FolderOpen size={16} /> Projects
            </NavLink>
            <NavLink to="/ai" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}>
              <Sparkles size={16} /> AI Tools
              {health?.ai_enabled && <span className={styles.aiBadge}>ON</span>}
            </NavLink>
          </nav>
          <div className={styles.sidebarFooter}>
            <div className={`${styles.statusDot} ${health?.status === 'ok' ? styles.online : styles.offline}`} />
            <span>{health?.status === 'ok' ? 'API connected' : 'API offline'}</span>
          </div>
        </aside>
        <main className={styles.main}>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/ai" element={<AiTools />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}
