import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

// Tasks
export const getTasks = (params) => api.get('/tasks/', { params }).then(r => r.data)
export const createTask = (data) => api.post('/tasks/', data).then(r => r.data)
export const updateTask = (id, data) => api.put(`/tasks/${id}`, data).then(r => r.data)
export const deleteTask = (id) => api.delete(`/tasks/${id}`).then(r => r.data)
export const getTaskStats = () => api.get('/tasks/stats').then(r => r.data)

// Projects
export const getProjects = () => api.get('/projects/').then(r => r.data)
export const createProject = (data) => api.post('/projects/', data).then(r => r.data)
export const updateProject = (id, data) => api.put(`/projects/${id}`, data).then(r => r.data)
export const deleteProject = (id) => api.delete(`/projects/${id}`).then(r => r.data)

// AI
export const aiPrioritize = () => api.post('/ai/prioritize').then(r => r.data)
export const aiSuggest = (data) => api.post('/ai/suggest', data).then(r => r.data)
export const aiSummarize = () => api.get('/ai/summarize').then(r => r.data)
export const getHealth = () => api.get('/health').then(r => r.data)

export default api
