import { useQuery } from '@tanstack/react-query'
import { getTaskStats, getTasks } from '../api'
import { CheckCircle2, Clock, AlertTriangle, TrendingUp, Flame, Target } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import styles from './Dashboard.module.css'
import { PRIORITY_CONFIG, STATUS_CONFIG } from '../utils/config'

function StatCard({ icon: Icon, label, value, color, sub }) {
  return (
    <div className={styles.statCard} style={{ '--card-accent': color }}>
      <div className={styles.statIcon}><Icon size={18} /></div>
      <div className={styles.statBody}>
        <div className={styles.statValue}>{value}</div>
        <div className={styles.statLabel}>{label}</div>
        {sub && <div className={styles.statSub}>{sub}</div>}
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { data: stats } = useQuery({ queryKey: ['stats'], queryFn: getTaskStats })
  const { data: tasks } = useQuery({
    queryKey: ['tasks', { sort_by: 'ai_priority_score', order: 'desc' }],
    queryFn: () => getTasks({ sort_by: 'ai_priority_score', order: 'desc' }),
  })
  const { data: recent } = useQuery({
    queryKey: ['tasks', { sort_by: 'created_at', order: 'desc' }],
    queryFn: () => getTasks({ sort_by: 'created_at', order: 'desc' }),
  })

  const topTasks = tasks?.filter(t => t.status !== 'done' && t.ai_priority_score != null).slice(0, 5)
  const recentTasks = recent?.slice(0, 8)

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Dashboard</h1>
          <p className={styles.subtitle}>Your productivity at a glance</p>
        </div>
      </div>

      <div className={styles.stats}>
        <StatCard icon={Target} label="Total Tasks" value={stats?.total ?? '—'} color="var(--accent)" />
        <StatCard icon={CheckCircle2} label="Completed" value={stats?.done ?? '—'} color="var(--green)" sub={stats ? `${stats.completion_rate}% rate` : null} />
        <StatCard icon={Clock} label="In Progress" value={stats?.in_progress ?? '—'} color="var(--blue)" />
        <StatCard icon={AlertTriangle} label="Overdue" value={stats?.overdue ?? '—'} color="var(--red)" />
        <StatCard icon={Flame} label="Urgent" value={stats?.urgent ?? '—'} color="var(--amber)" />
        <StatCard icon={TrendingUp} label="Completion Rate" value={stats ? `${stats.completion_rate}%` : '—'} color="var(--accent-2)" />
      </div>

      <div className={styles.grid}>
        {topTasks && topTasks.length > 0 && (
          <div className={styles.section}>
            <h2 className={styles.sectionTitle}>
              <span className={styles.aiTag}>AI</span> Top Priority Tasks
            </h2>
            <div className={styles.taskList}>
              {topTasks.map((task, i) => (
                <div key={task.id} className={styles.priorityRow}>
                  <div className={styles.rankNum}>{i + 1}</div>
                  <div className={styles.priorityInfo}>
                    <div className={styles.priorityTitle}>{task.title}</div>
                    {task.ai_reasoning && (
                      <div className={styles.reasoning}>{task.ai_reasoning}</div>
                    )}
                  </div>
                  <div className={styles.scoreBar}>
                    <div className={styles.scoreTrack}>
                      <div
                        className={styles.scoreFill}
                        style={{ width: `${(task.ai_priority_score / 10) * 100}%` }}
                      />
                    </div>
                    <span className={styles.scoreNum}>{task.ai_priority_score?.toFixed(1)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Recent Tasks</h2>
          <div className={styles.taskList}>
            {recentTasks?.map(task => {
              const p = PRIORITY_CONFIG[task.priority]
              const s = STATUS_CONFIG[task.status]
              return (
                <div key={task.id} className={styles.recentRow}>
                  <span className={styles.recentDot} style={{ background: p?.color }} />
                  <span className={styles.recentTitle}>{task.title}</span>
                  <span className={styles.recentStatus} style={{ color: s?.color }}>{s?.label}</span>
                  <span className={styles.recentTime}>
                    {formatDistanceToNow(new Date(task.created_at), { addSuffix: true })}
                  </span>
                </div>
              )
            })}
            {!recentTasks?.length && (
              <div className={styles.empty}>No tasks yet. Create your first task!</div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
