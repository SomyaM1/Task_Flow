import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getTasks, createTask, updateTask, deleteTask, getProjects } from '../api'
import { Plus, Trash2, Edit2, ChevronDown, Search, X, Check, SortAsc } from 'lucide-react'
import { format } from 'date-fns'
import styles from './Tasks.module.css'
import { PRIORITY_CONFIG, STATUS_CONFIG } from '../utils/config'

const STATUSES = ['todo', 'in_progress', 'done']

function TaskForm({ task, projects, onSave, onCancel }) {
  const [form, setForm] = useState({
    title: task?.title || '',
    description: task?.description || '',
    priority: task?.priority || 'medium',
    status: task?.status || 'todo',
    project_id: task?.project_id || '',
    due_date: task?.due_date ? task.due_date.slice(0, 10) : '',
    tags: task?.tags?.join(', ') || '',
  })

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const handleSave = () => {
    if (!form.title.trim()) return
    const tags = form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : []
    onSave({
      ...form,
      project_id: form.project_id ? parseInt(form.project_id) : null,
      tags,
      due_date: form.due_date || null,
    })
  }

  return (
    <div className={styles.formCard}>
      <input
        className={styles.titleInput}
        placeholder="Task title…"
        value={form.title}
        onChange={e => set('title', e.target.value)}
        autoFocus
        onKeyDown={e => e.key === 'Enter' && handleSave()}
      />
      <textarea
        className={styles.descInput}
        placeholder="Description (optional)…"
        value={form.description}
        onChange={e => set('description', e.target.value)}
        rows={3}
      />
      <div className={styles.formRow}>
        <select className={styles.select} value={form.priority} onChange={e => set('priority', e.target.value)}>
          {Object.entries(PRIORITY_CONFIG).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
        <select className={styles.select} value={form.status} onChange={e => set('status', e.target.value)}>
          {Object.entries(STATUS_CONFIG).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
        <select className={styles.select} value={form.project_id} onChange={e => set('project_id', e.target.value)}>
          <option value="">No project</option>
          {projects?.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input
          type="date"
          className={styles.select}
          value={form.due_date}
          onChange={e => set('due_date', e.target.value)}
        />
      </div>
      <div className={styles.formRow}>
        <input
          className={styles.tagInput}
          placeholder="Tags (comma-separated)"
          value={form.tags}
          onChange={e => set('tags', e.target.value)}
        />
      </div>
      <div className={styles.formActions}>
        <button className={styles.cancelBtn} onClick={onCancel}>Cancel</button>
        <button className={styles.saveBtn} onClick={handleSave}>
          <Check size={14} /> {task ? 'Update' : 'Create Task'}
        </button>
      </div>
    </div>
  )
}

function TaskCard({ task, onEdit, onDelete, onStatusChange }) {
  const p = PRIORITY_CONFIG[task.priority]
  const s = STATUS_CONFIG[task.status]

  return (
    <div className={`${styles.taskCard} ${task.status === 'done' ? styles.done : ''}`}>
      <div className={styles.taskHeader}>
        <button
          className={`${styles.checkbox} ${task.status === 'done' ? styles.checked : ''}`}
          onClick={() => onStatusChange(task, task.status === 'done' ? 'todo' : 'done')}
        >
          {task.status === 'done' && <Check size={11} />}
        </button>
        <span className={styles.taskTitle}>{task.title}</span>
        <div className={styles.taskActions}>
          <button className={styles.iconBtn} onClick={() => onEdit(task)}><Edit2 size={13} /></button>
          <button className={`${styles.iconBtn} ${styles.danger}`} onClick={() => onDelete(task.id)}><Trash2 size={13} /></button>
        </div>
      </div>

      {task.description && (
        <p className={styles.taskDesc}>{task.description}</p>
      )}

      <div className={styles.taskMeta}>
        <span className={styles.priorityBadge} style={{ color: p.color, borderColor: p.color }}>
          {p.label}
        </span>
        <span className={styles.statusBadge} style={{ color: s.color }}>
          {s.label}
        </span>
        {task.project && (
          <span className={styles.projectBadge} style={{ '--proj-color': task.project.color }}>
            {task.project.name}
          </span>
        )}
        {task.due_date && (
          <span className={styles.dueBadge}>
            {format(new Date(task.due_date), 'MMM d')}
          </span>
        )}
        {task.ai_priority_score != null && (
          <span className={styles.aiScore}>
            AI: {task.ai_priority_score.toFixed(1)}
          </span>
        )}
        {task.tags?.map(tag => (
          <span key={tag} className={styles.tag}>#{tag}</span>
        ))}
      </div>

      {task.ai_reasoning && (
        <div className={styles.aiReasoning}>{task.ai_reasoning}</div>
      )}
    </div>
  )
}

export default function Tasks() {
  const qc = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [editTask, setEditTask] = useState(null)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [filterPriority, setFilterPriority] = useState('')
  const [sortBy, setSortBy] = useState('created_at')

  const params = {
    search: search || undefined,
    status: filterStatus || undefined,
    priority: filterPriority || undefined,
    sort_by: sortBy,
    order: sortBy === 'ai_priority_score' ? 'desc' : 'desc',
  }

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['tasks', params],
    queryFn: () => getTasks(params),
  })

  const { data: projects } = useQuery({ queryKey: ['projects'], queryFn: getProjects })

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['tasks'] })
    qc.invalidateQueries({ queryKey: ['stats'] })
  }

  const createMutation = useMutation({
    mutationFn: createTask,
    onSuccess: () => { invalidate(); setShowForm(false) },
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }) => updateTask(id, data),
    onSuccess: () => { invalidate(); setEditTask(null) },
  })

  const deleteMutation = useMutation({
    mutationFn: deleteTask,
    onSuccess: invalidate,
  })

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Tasks</h1>
        <button className={styles.addBtn} onClick={() => setShowForm(true)}>
          <Plus size={16} /> New Task
        </button>
      </div>

      <div className={styles.toolbar}>
        <div className={styles.searchWrap}>
          <Search size={14} className={styles.searchIcon} />
          <input
            className={styles.searchInput}
            placeholder="Search tasks…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          {search && <button className={styles.clearSearch} onClick={() => setSearch('')}><X size={12} /></button>}
        </div>
        <select className={styles.filterSelect} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">All statuses</option>
          {Object.entries(STATUS_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select className={styles.filterSelect} value={filterPriority} onChange={e => setFilterPriority(e.target.value)}>
          <option value="">All priorities</option>
          {Object.entries(PRIORITY_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select className={styles.filterSelect} value={sortBy} onChange={e => setSortBy(e.target.value)}>
          <option value="created_at">Newest first</option>
          <option value="due_date">Due date</option>
          <option value="ai_priority_score">AI Score</option>
          <option value="priority">Priority</option>
        </select>
      </div>

      {(showForm && !editTask) && (
        <TaskForm
          projects={projects}
          onSave={data => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
        />
      )}

      {isLoading && <div className={styles.loading}>Loading tasks…</div>}

      <div className={styles.taskList}>
        {tasks?.map(task => (
          editTask?.id === task.id ? (
            <TaskForm
              key={task.id}
              task={task}
              projects={projects}
              onSave={data => updateMutation.mutate({ id: task.id, ...data })}
              onCancel={() => setEditTask(null)}
            />
          ) : (
            <TaskCard
              key={task.id}
              task={task}
              onEdit={setEditTask}
              onDelete={id => deleteMutation.mutate(id)}
              onStatusChange={(t, status) => updateMutation.mutate({ id: t.id, status })}
            />
          )
        ))}
        {tasks?.length === 0 && !isLoading && (
          <div className={styles.empty}>
            No tasks found.{' '}
            <button className={styles.emptyBtn} onClick={() => setShowForm(true)}>Create one?</button>
          </div>
        )}
      </div>
    </div>
  )
}
