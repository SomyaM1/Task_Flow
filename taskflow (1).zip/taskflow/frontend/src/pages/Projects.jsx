import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getProjects, createProject, updateProject, deleteProject } from '../api'
import { Plus, Trash2, Edit2, FolderOpen, Check } from 'lucide-react'
import styles from './Projects.module.css'
import { PROJECT_COLORS } from '../utils/config'

function ProjectForm({ project, onSave, onCancel }) {
  const [name, setName] = useState(project?.name || '')
  const [description, setDescription] = useState(project?.description || '')
  const [color, setColor] = useState(project?.color || PROJECT_COLORS[0])

  const handleSave = () => {
    if (!name.trim()) return
    onSave({ name: name.trim(), description: description.trim(), color })
  }

  return (
    <div className={styles.formCard}>
      <input
        className={styles.nameInput}
        placeholder="Project name…"
        value={name}
        onChange={e => setName(e.target.value)}
        autoFocus
        onKeyDown={e => e.key === 'Enter' && handleSave()}
      />
      <textarea
        className={styles.descInput}
        placeholder="Description (optional)…"
        value={description}
        onChange={e => setDescription(e.target.value)}
        rows={2}
      />
      <div className={styles.colorRow}>
        <span className={styles.colorLabel}>Color:</span>
        {PROJECT_COLORS.map(c => (
          <button
            key={c}
            className={`${styles.colorSwatch} ${c === color ? styles.colorActive : ''}`}
            style={{ background: c }}
            onClick={() => setColor(c)}
          />
        ))}
      </div>
      <div className={styles.formActions}>
        <button className={styles.cancelBtn} onClick={onCancel}>Cancel</button>
        <button className={styles.saveBtn} onClick={handleSave}>
          <Check size={14} /> {project ? 'Update' : 'Create Project'}
        </button>
      </div>
    </div>
  )
}

function ProjectCard({ project, onEdit, onDelete }) {
  const pct = project.task_count > 0
    ? Math.round((project.completed_count / project.task_count) * 100)
    : 0

  return (
    <div className={styles.card}>
      <div className={styles.cardTop}>
        <div className={styles.colorDot} style={{ background: project.color }} />
        <div className={styles.cardActions}>
          <button className={styles.iconBtn} onClick={() => onEdit(project)}><Edit2 size={13} /></button>
          <button className={`${styles.iconBtn} ${styles.danger}`} onClick={() => onDelete(project.id)}><Trash2 size={13} /></button>
        </div>
      </div>
      <h3 className={styles.cardName}>{project.name}</h3>
      {project.description && <p className={styles.cardDesc}>{project.description}</p>}
      <div className={styles.cardStats}>
        <span>{project.task_count} tasks</span>
        <span>{project.completed_count} done</span>
      </div>
      {project.task_count > 0 && (
        <div className={styles.progressWrap}>
          <div className={styles.progressTrack}>
            <div className={styles.progressFill} style={{ width: `${pct}%`, background: project.color }} />
          </div>
          <span className={styles.progressPct}>{pct}%</span>
        </div>
      )}
    </div>
  )
}

export default function Projects() {
  const qc = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [editProject, setEditProject] = useState(null)

  const { data: projects, isLoading } = useQuery({ queryKey: ['projects'], queryFn: getProjects })

  const invalidate = () => qc.invalidateQueries({ queryKey: ['projects'] })

  const createMut = useMutation({
    mutationFn: createProject,
    onSuccess: () => { invalidate(); setShowForm(false) },
  })
  const updateMut = useMutation({
    mutationFn: ({ id, ...data }) => updateProject(id, data),
    onSuccess: () => { invalidate(); setEditProject(null) },
  })
  const deleteMut = useMutation({
    mutationFn: deleteProject,
    onSuccess: invalidate,
  })

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Projects</h1>
        <button className={styles.addBtn} onClick={() => setShowForm(true)}>
          <Plus size={16} /> New Project
        </button>
      </div>

      {showForm && !editProject && (
        <ProjectForm
          onSave={data => createMut.mutate(data)}
          onCancel={() => setShowForm(false)}
        />
      )}

      {editProject && (
        <ProjectForm
          project={editProject}
          onSave={data => updateMut.mutate({ id: editProject.id, ...data })}
          onCancel={() => setEditProject(null)}
        />
      )}

      {isLoading && <div className={styles.loading}>Loading projects…</div>}

      <div className={styles.grid}>
        {projects?.map(project => (
          <ProjectCard
            key={project.id}
            project={project}
            onEdit={setEditProject}
            onDelete={id => deleteMut.mutate(id)}
          />
        ))}
        {projects?.length === 0 && !isLoading && (
          <div className={styles.empty}>
            <FolderOpen size={40} className={styles.emptyIcon} />
            <p>No projects yet.</p>
            <button className={styles.emptyBtn} onClick={() => setShowForm(true)}>Create your first project</button>
          </div>
        )}
      </div>
    </div>
  )
}
