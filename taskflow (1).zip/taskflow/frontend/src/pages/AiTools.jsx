import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { aiPrioritize, aiSuggest, aiSummarize, createTask, getProjects } from '../api'
import { Sparkles, Zap, MessageSquare, Plus, Check, Loader } from 'lucide-react'
import styles from './AiTools.module.css'

function Spinner() {
  return <div className={styles.spinner} />
}

export default function AiTools() {
  const qc = useQueryClient()
  const [goal, setGoal] = useState('')
  const [selectedProjectId, setSelectedProjectId] = useState('')
  const [suggestions, setSuggestions] = useState([])
  const [addedIds, setAddedIds] = useState(new Set())
  const [summary, setSummary] = useState('')

  const { data: projects } = useQuery({ queryKey: ['projects'], queryFn: getProjects })

  const prioritizeMut = useMutation({
    mutationFn: aiPrioritize,
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['tasks'] })
    },
  })

  const suggestMut = useMutation({
    mutationFn: aiSuggest,
    onSuccess: (data) => setSuggestions(data.suggestions || []),
  })

  const summarizeMut = useMutation({
    mutationFn: aiSummarize,
    onSuccess: (data) => setSummary(data.summary),
  })

  const addTaskMut = useMutation({
    mutationFn: createTask,
    onSuccess: (data, vars, ctx) => {
      setAddedIds(s => new Set([...s, vars._suggIdx]))
      qc.invalidateQueries({ queryKey: ['tasks'] })
      qc.invalidateQueries({ queryKey: ['stats'] })
    },
  })

  const handleAddSuggestion = (s, idx) => {
    addTaskMut.mutate({
      _suggIdx: idx,
      title: s.title,
      description: s.description,
      priority: s.priority,
      tags: s.suggested_tags || [],
      project_id: selectedProjectId ? parseInt(selectedProjectId) : null,
    })
  }

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>
          <Sparkles size={24} className={styles.sparkle} />
          AI Tools
        </h1>
        <p className={styles.subtitle}>Powered by Claude — analyze, prioritize, and plan smarter</p>
      </div>

      <div className={styles.grid}>

        {/* AI Prioritize */}
        <div className={styles.card}>
          <div className={styles.cardIcon} style={{ '--ci': 'var(--accent)' }}>
            <Zap size={20} />
          </div>
          <h2 className={styles.cardTitle}>Smart Prioritization</h2>
          <p className={styles.cardDesc}>
            Claude analyzes all your pending tasks and assigns AI priority scores (0–10) based on urgency, due dates, and task context.
          </p>
          <button
            className={styles.actionBtn}
            onClick={() => prioritizeMut.mutate()}
            disabled={prioritizeMut.isPending}
          >
            {prioritizeMut.isPending ? <><Spinner /> Analyzing tasks…</> : <><Zap size={14} /> Run AI Prioritization</>}
          </button>
          {prioritizeMut.isSuccess && (
            <div className={styles.result}>
              ✓ {prioritizeMut.data.message}. Check the Tasks page to see AI scores.
            </div>
          )}
          {prioritizeMut.isError && (
            <div className={styles.error}>
              {prioritizeMut.error?.response?.data?.error || 'Error running AI. Make sure ANTHROPIC_API_KEY is set.'}
            </div>
          )}
        </div>

        {/* Workload Summary */}
        <div className={styles.card}>
          <div className={styles.cardIcon} style={{ '--ci': 'var(--green)' }}>
            <MessageSquare size={20} />
          </div>
          <h2 className={styles.cardTitle}>Workload Summary</h2>
          <p className={styles.cardDesc}>
            Get a natural language summary of your current workload with actionable recommendations from Claude.
          </p>
          <button
            className={`${styles.actionBtn} ${styles.greenBtn}`}
            onClick={() => summarizeMut.mutate()}
            disabled={summarizeMut.isPending}
          >
            {summarizeMut.isPending ? <><Spinner /> Summarizing…</> : <><MessageSquare size={14} /> Summarize My Workload</>}
          </button>
          {summary && (
            <div className={styles.summaryBox}>
              <div className={styles.summaryLabel}><Sparkles size={12} /> Claude says</div>
              <p className={styles.summaryText}>{summary}</p>
            </div>
          )}
          {summarizeMut.isError && (
            <div className={styles.error}>
              {summarizeMut.error?.response?.data?.error || 'Error running AI.'}
            </div>
          )}
        </div>
      </div>

      {/* Task Suggestions */}
      <div className={styles.suggestSection}>
        <div className={styles.suggestCard}>
          <div className={styles.suggestHeader}>
            <div className={styles.cardIcon} style={{ '--ci': 'var(--amber)' }}>
              <Plus size={20} />
            </div>
            <div>
              <h2 className={styles.cardTitle}>AI Task Generator</h2>
              <p className={styles.cardDesc}>Describe a goal or project, and Claude will suggest a set of actionable tasks to get you started.</p>
            </div>
          </div>

          <div className={styles.inputRow}>
            <textarea
              className={styles.goalInput}
              placeholder="e.g. 'Launch a personal blog', 'Prepare for a product demo', 'Plan a team hackathon'…"
              value={goal}
              onChange={e => setGoal(e.target.value)}
              rows={3}
            />
          </div>
          <div className={styles.inputRow}>
            <select
              className={styles.projectSelect}
              value={selectedProjectId}
              onChange={e => setSelectedProjectId(e.target.value)}
            >
              <option value="">No project (optional)</option>
              {projects?.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <button
              className={`${styles.actionBtn} ${styles.amberBtn}`}
              onClick={() => { setSuggestions([]); setAddedIds(new Set()); suggestMut.mutate({ goal, project_id: selectedProjectId || null }) }}
              disabled={suggestMut.isPending || !goal.trim()}
            >
              {suggestMut.isPending ? <><Spinner /> Generating…</> : <><Sparkles size={14} /> Generate Tasks</>}
            </button>
          </div>

          {suggestMut.isError && (
            <div className={styles.error}>
              {suggestMut.error?.response?.data?.error || 'Error running AI.'}
            </div>
          )}

          {suggestions.length > 0 && (
            <div className={styles.suggestions}>
              <div className={styles.suggestionsLabel}>
                {suggestions.length} suggested tasks — click + to add them:
              </div>
              {suggestions.map((s, i) => (
                <div key={i} className={`${styles.suggRow} ${addedIds.has(i) ? styles.suggAdded : ''}`}>
                  <div className={styles.suggInfo}>
                    <div className={styles.suggTitle}>{s.title}</div>
                    <div className={styles.suggDesc}>{s.description}</div>
                    <div className={styles.suggMeta}>
                      <span className={styles.suggPriority} data-p={s.priority}>{s.priority}</span>
                      {s.suggested_tags?.map(t => <span key={t} className={styles.suggTag}>#{t}</span>)}
                    </div>
                  </div>
                  <button
                    className={styles.addSuggBtn}
                    onClick={() => handleAddSuggestion(s, i)}
                    disabled={addedIds.has(i)}
                  >
                    {addedIds.has(i) ? <Check size={14} /> : <Plus size={14} />}
                  </button>
                </div>
              ))}
              {suggestions.length > 0 && (
                <button
                  className={styles.addAllBtn}
                  onClick={() => suggestions.forEach((s, i) => !addedIds.has(i) && handleAddSuggestion(s, i))}
                  disabled={addedIds.size === suggestions.length}
                >
                  Add All Tasks
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
